// creating an array and passing the number, questions, options, and answers
let questions = [
    {
    numb: 1,
    question: "What is my Name?",
    answer: "ARJAD",
    options: [
      "ALI",
      "SAHIR",
      "ARJAD",
      "NONE"
    ]
  },
    {
    numb: 2,
    question: "What is my age?",
    answer: "22",
    options: [
      "21",
      "22",
      "23",
      "26"
    ]
  },
    {
    numb: 3,
    question: "My Hobby?",
    answer: "SWIM",
    options: [
      "TV",
      "PLAYING",
      "SINGING",
      "SWIM"
    ]
  }
];